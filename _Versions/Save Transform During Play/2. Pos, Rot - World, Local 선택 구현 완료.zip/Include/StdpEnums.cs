﻿
namespace Rito.Conveniences
{
    public enum PositionSpace
    {
        World,
        Local,
    }

    public enum RotationSpace
    {
        World,
        Local,
    }

    public enum ScaleSpace
    {
        // TODO : World
        Local,
    }
}
